
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Titanic Dashboard", layout="wide")

st.title("🚢 Titanic Dashboard")

df = pd.read_csv("titanic_sample.csv")

st.subheader("Dataset Titanic")
st.dataframe(df)

st.subheader("Statistik Dataset")
st.write(df.describe())

if "Survived" in df.columns:
    st.subheader("Grafik Survival")

    fig, ax = plt.subplots()
    df["Survived"].value_counts().plot(kind="bar", ax=ax)
    st.pyplot(fig)

if "Age" in df.columns:
    st.subheader("Distribusi Umur")

    fig2, ax2 = plt.subplots()
    df["Age"].plot(kind="hist", bins=10, ax=ax2)
    st.pyplot(fig2)

st.success("Aplikasi berhasil berjalan 🚀")
